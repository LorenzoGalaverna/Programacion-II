#ifndef CAJASEGURIDAD_H
#define CAJASEGURIDAD_H

class CajaSeguridad {
private:
    int codigo;
public:
    CajaSeguridad();
    void setCodigo(int codigo);
    int getCodigo();
};

#endif
